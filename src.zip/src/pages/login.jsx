// // jsx;
// import React, { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";

// const LoginPage = () => {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [error, setError] = useState("");
//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     // Send a POST request to the server for authentication
//     try {
//       const response = await axios.post(
//         "https://5d58-115-246-25-131.ngrok-free.app/users/login",
//         {
//           email: username,
//           password: password,
//         }
//       );

//       // Check if login was successful
//       if (response.status === 200) {
//         // Navigate to the homepage
//         navigate("/home");
//       } else {
//         setError("Invalid credentials");
//       }
//     } catch (err) {
//       setError(`An error occurred during login : ${err}`);
//     }
//   };

//   return (
//     <div className="flex items-center justify-center h-screen bg-gray-100">
//       <div className="bg-white p-8 rounded shadow-md w-96 max-w-md">
//         <h1 className="text-3xl font-bold mb-6 text-center text-blue-600">
//           Login
//         </h1>
//         <form onSubmit={handleSubmit} className="space-y-4">
//           <div>
//             <label
//               htmlFor="username"
//               className="block text-sm font-medium text-gray-700 mb-1"
//             >
//               Username:
//             </label>
//             <input
//               type="text"
//               id="username"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
//             />
//           </div>
//           <div>
//             <label
//               htmlFor="password"
//               className="block text-sm font-medium text-gray-700 mb-1"
//             >
//               Password:
//             </label>
//             <input
//               type="password"
//               id="password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
//             />
//           </div>
//           <button
//             type="submit"
//             className="w-full bg-blue-500 text-white py-2 rounded shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
//           >
//             Login
//           </button>
//         </form>
//         {error && (
//           <p className="mt-4 text-red-500 text-sm text-center">{error}</p>
//         )}
//         <p className="mt-4 text-center text-gray-600">
//           Don't have an account?{" "}
//           <Link to="/register" className="text-blue-500 hover:underline">
//             Sign up now!
//           </Link>
//         </p>
//       </div>
//     </div>
//   );
// };

// export default LoginPage;

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const LoginPage = ({ handleLogin }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false); // State for tracking login success
  const navigate = useNavigate();

  const validateFields = (username, password) => {
    const validationErrors = {};

    if (!username) {
      validationErrors.username = "Username is required.";
    }

    if (!password) {
      validationErrors.password = "Password is required.";
    }

    return validationErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate the form fields
    const validationErrors = validateFields(username, password);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    // Send a POST request to the server for authentication
    try {
      const response = await axios.post(
        "https://5d58-115-246-25-131.ngrok-free.app/users/login",
        {
          email: username,
          password,
        }
      );

      // Check if login was successful
      if (response.status === 200) {
        // Set success status
        setSuccess(true);

        // Redirect to the homepage after a short delay
        setTimeout(() => {
          handleLogin();
          navigate("/home");
        }, 1500);
      } else {
        setErrors({ form: "Invalid credentials" });
      }
    } catch (err) {
      setErrors({ form: `An error occurred during login: ${err.message}` });
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded shadow-md w-96 max-w-md">
        <h1 className="text-3xl font-bold mb-6 text-center text-blue-600">
          Login
        </h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="username"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Username:
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            {errors.username && (
              <p className="text-red-500 text-sm">{errors.username}</p>
            )}
          </div>
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Password:
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            {errors.password && (
              <p className="text-red-500 text-sm">{errors.password}</p>
            )}
          </div>
          <button
            type="submit"
            className="w-full bg-blue-500 text-white py-2 rounded shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            Login
          </button>
        </form>
        {errors.form && (
          <p className="mt-4 text-red-500 text-sm text-center">{errors.form}</p>
        )}
        <p className="mt-4 text-center text-gray-600">
          Don't have an account?{" "}
          <Link to="/register" className="text-blue-500 hover:underline">
            Sign up now!
          </Link>
        </p>
        <p className="mt-4 text-center text-gray-600">
          <Link to="/forgotPassword" className="text-blue-500 hover:underline">
            Forgot Password ?
          </Link>
        </p>
      </div>

      {/* Popup for successful login */}
      {success && (
        <div className="fixed bottom-10 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white py-2 px-4 rounded shadow-lg text-sm font-bold">
          Login successfully!
        </div>
      )}
    </div>
  );
};

export default LoginPage;
