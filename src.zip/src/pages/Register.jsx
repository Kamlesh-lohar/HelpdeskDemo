import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Register1() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    // Validate the form fields
    const validationErrors = validateFields(username, email, password);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      const response = await axios.post(
        "https://5d58-115-246-25-131.ngrok-free.app/users/register",
        {
          name: username,
          password,
          email,
        }
      );

      // Check if registration was successful
      if (response.status === 201) {
        setSuccess(true); // Set success state to true
        setTimeout(() => {
          setSuccess(false); // Hide success popup after 3 seconds
          navigate("/"); // Redirect to homepage
        }, 3000);
      } else {
        setErrors({ form: "Invalid credentials" });
      }
    } catch (err) {
      setErrors({ form: `An error occurred during registration: ${err}` });
    }
  };

  // Function to validate the form fields
  const validateFields = (username, email, password) => {
    const validationErrors = {};

    if (!username) {
      validationErrors.username = "Username is required.";
    }

    if (!email) {
      validationErrors.email = "Email is required.";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        validationErrors.email = "Invalid email format.";
      }
    }

    if (!password) {
      validationErrors.password = "Password is required.";
    }

    return validationErrors;
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-200">
      <div className="w-full max-w-md">
        <h1 className="font-bold text-center text-blue-500 mb-10 tracking-widest font-gilroy text-2xl">
          Register/Sign-Up
        </h1>
        <form
          onSubmit={handleRegister}
          className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 drop-shadow-2xl"
        >
          <div className="mb-4">
            <label
              className="block text-gray-700 text-sm font-bold mb-2"
              htmlFor="username"
            >
              Username
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="username"
              type="text"
              placeholder="Username"
              pattern="[A-Za-z0-9]+"
              title="Username should only contain letters and numbers"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            {errors.username && (
              <p className="text-red-500 text-sm">{errors.username}</p>
            )}
          </div>
          <div className="mb-4">
            <label
              className="block text-gray-700 text-sm font-bold mb-2"
              htmlFor="email"
            >
              Email
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="email"
              type="email"
              placeholder="Email"
              pattern=".+@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            {errors.email && (
              <p className="text-red-500 text-sm">{errors.email}</p>
            )}
          </div>
          <div className="mb-6">
            <label
              className="block text-gray-700 text-sm font-bold mb-2"
              htmlFor="password"
            >
              Password
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="password"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {errors.password && (
              <p className="text-red-500 text-sm">{errors.password}</p>
            )}
          </div>
          <div className="flex items-center justify-center">
            <button
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
              type="submit"
            >
              Register
            </button>
          </div>
        </form>

        {/* Display form-level error if any */}
        {errors.form && (
          <p className="mt-4 text-red-500 text-sm text-center">{errors.form}</p>
        )}

        {/* Success popup */}
        {success && (
          <div className="fixed bottom-10 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white py-2 px-4 rounded shadow-lg text-sm font-bold">
            Registered successfully!
          </div>
        )}
      </div>
    </div>
  );
}

export default Register1;
