import React from "react";
import { Link, useNavigate } from "react-router-dom";
import ArrowRightOnRectangleIcon from "@heroicons/react/24/outline/ArrowRightEndOnRectangleIcon"; // Import the logout icon from Heroicons
import UserIcon from "@heroicons/react/24/outline/UserIcon";
import TicketIcon from "@heroicons/react/24/outline/TicketIcon";

const Home = ({ username, onLogout }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Perform any necessary logout operations (e.g., clearing user data)
    if (onLogout) {
      onLogout();
    }
    // Redirect to the login page or other appropriate page after logout
    navigate("/login");
  };
  return (
    <div className="min-h-screen flex flex-col">
      {/* Horizontal Bar (Header) */}
      <div className="bg-blue-800 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          {/* Top navigation brand or logo */}
          <div className="text-xl font-bold">Jignect Helpdesk</div>

          {/* Add any other top navigation links or options here */}
          <div className="flex items-center">
            <button
              // onClick={handleLogout}
              className="text-white text-xl font-bold hover:underline flex items-center"
            >
              Logout
              <ArrowRightOnRectangleIcon className="w-6 h-6 ml-2" />{" "}
              {/* Add logout icon */}
            </button>
          </div>
        </div>
      </div>

      {/* Main content and vertical navigation */}
      <div className="flex flex-grow">
        {/* Vertical Navbar */}
        <nav className="bg-zinc-600 w-32 p-4 flex flex-col">
          {/* Brand or logo */}
          <div className="text-white text-xl font-bold mb-8 pl-4">Home</div>

          {/* Navigation links */}
          <Link
            to="/profile"
            className="text-white flex flex-col items-center mb-4 hover:underline"
          >
            <UserIcon className="w-6 h-6" />
            <span className="mt-1">My Profile</span>
          </Link>
          <Link
            to="/tickets"
            className="text-white flex flex-col items-center hover:underline"
          >
            <TicketIcon className="w-6 h-6" />
            <span className="mt-1">My Tickets</span>
          </Link>
        </nav>

        {/* Main content */}
        <div className="flex-grow p-8">
          <h1 className="text-3xl font-bold text-blue-800">
            Welcome, {username}!
          </h1>
          <p className="mt-4 text-gray-700">You are now on the home page.</p>
        </div>
      </div>
    </div>
  );
};

export default Home;
