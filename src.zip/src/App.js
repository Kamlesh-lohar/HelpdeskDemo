// import React from "react";
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import LoginPage3 from "./pages/login";
// import Register from "./pages/Register";
// import Home from "./pages/Home";
// import Register1 from "./pages/Home1";
// // import Reg from "./pages/Home1";

// function App() {
//   return (
//     <>
//       <Router>
//         <Routes>
//           <Route exact path="/" element={<LoginPage3 />} />
//           <Route path="/home" element={<Home />} />
//           <Route path="/home1" element={<Register1 />} />
//           <Route path="/register" element={<Register />} />
//         </Routes>
//       </Router>
//     </>
//   );
// }
// export default App;

import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import LoginPage3 from "./pages/login";
import Register from "./pages/Register";

import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const handleLogin = () => {
    setIsAuthenticated(true);
  };
  return (
    <Router>
      <Routes>
        <Route
          exact
          path="/"
          element={<LoginPage3 handleLogin={handleLogin} />}
        />
        <Route path="/register" element={<Register />} />
        <Route
          path="/home"
          element={
            <ProtectedRoute
              children={<Home />}
              isAuthenticated={isAuthenticated}
            />
          }
        />
      </Routes>
    </Router>
  );
}
export default App;
