// import React from "react";

// function SuccessMessage({ children }) {
//   return (
//     <div className="fixed bottom-10 left-[85%] transform -translate-x-1/2 z-50 bg-green-500 text-white py-2 px-4 rounded shadow-lg text-sm font-bold">
//       {children}
//     </div>
//   );
// }

// export default SuccessMessage;
