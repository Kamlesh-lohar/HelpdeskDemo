import axios from "axios";

const BaseApi = axios.create({
  baseURL: " https://217b-115-246-25-131.ngrok-free.app", // Your API base URL
});

export default BaseApi;
