// api.js
import BaseApi from "./BaseApi";

import {
  USER_LOGIN_ENDPOINT,
  USER_VERIFY_REGISTER_ENDPOINT,
  USER_REGISTER_ENDPOINT,
  USER_SEND_OTP_ENDPOINT,
  USER_VERIFY_OTP_ENDPOINT,
} from "./ApiEndpoints";

export default class ApiService {
  constructor(setLoading) {
    this.setLoading = setLoading;
  }

  login = async (email, password) => {
    try {
      this.setLoading(true);
      const response = await BaseApi.post(USER_LOGIN_ENDPOINT, {
        email,
        password,
      });
      // setLoading(false);
      return response;
    } catch (error) {
      this.setLoading(false);
      throw new Error(
        `An error occurred during login: ${error.response.data.message}`
      );
    } finally {
      this.setLoading(false);
    }
  };

  sendPasswordResetOTP = async (email) => {
    try {
      this.setLoading(true);
      const response = await BaseApi.patch(USER_SEND_OTP_ENDPOINT, { email });
      return response;
    } catch (error) {
      this.setLoading(false);
      throw new Error(error.response.data.message);
    } finally {
      this.setLoading(false);
    }
  };

  changePasswordWithOTP = async (email, otp, password, confirmPassword) => {
    try {
      const response = await BaseApi.patch(USER_VERIFY_OTP_ENDPOINT, {
        email: email,
        otp: otp,
        password: password,
        confirmPassword: confirmPassword,
      });
      return response;
    } catch (error) {
      throw new Error(error.response.data.message);
    }
  };

  sendRegisterOTP = async (username, email, password) => {
    try {
      this.setLoading(true);
      const response = await BaseApi.post(USER_REGISTER_ENDPOINT, {
        username,
        email,
        password,
      });
      return response;
    } catch (error) {
      this.setLoading(false);
      throw new Error(
        `An error occurred during registration: ${error.response.data.message}`
      );
    } finally {
      this.setLoading(false);
    }
  };

  verifyRegisterOTP = async (email, otp) => {
    try {
      const response = await BaseApi.patch(USER_VERIFY_REGISTER_ENDPOINT, {
        email,
        otp,
      });

      return response;
    } catch (error) {
      throw new Error(
        `An error occurred during registration: ${error.response.data.message}`
      );
    }
  };
}
