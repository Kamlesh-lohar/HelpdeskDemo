export const USER_LOGIN_ENDPOINT = "/user/login";
export const USER_REGISTER_ENDPOINT = "/user/register";
export const USER_VERIFY_REGISTER_ENDPOINT = "/user/verify/register";
export const USER_SEND_OTP_ENDPOINT = "/user/password/reset";
export const USER_VERIFY_OTP_ENDPOINT = "/user/password/save";
