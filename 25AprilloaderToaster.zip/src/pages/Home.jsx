import React from "react";
import { Link, useNavigate } from "react-router-dom";
import ArrowRightOnRectangleIcon from "@heroicons/react/24/outline/ArrowRightEndOnRectangleIcon"; // Import the logout icon from Heroicons
import UserIcon from "@heroicons/react/24/outline/UserIcon";
import TicketIcon from "@heroicons/react/24/outline/TicketIcon";

const Home = ({ username, onLogout }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Perform any necessary logout operations (e.g., clearing user data)
    if (onLogout) {
      onLogout();
    }
    // Redirect to the login page or other appropriate page after logout
    navigate("/", { replace: true });
  };
  return (
    <div className="min-h-screen flex flex-col">
      {/* Horizontal Bar (Header) */}
      <div className="bg-blue-800 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          {/* Top navigation brand or logo */}
          <div className="text-xl font-bold">Jignect Helpdesk</div>

          {/* Add any other top navigation links or options here */}
          <div className="flex items-center">
            <button
              onClick={handleLogout}
              className="text-white text-xl font-bold hover:underline flex items-center"
            >
              Logout
              <ArrowRightOnRectangleIcon className="w-6 h-6 ml-2" />{" "}
              {/* Add logout icon */}
            </button>
          </div>
        </div>
      </div>

      {/* Main content and vertical navigation */}
      <div className="flex flex-grow">
        {/* Vertical Navbar */}
        <nav className="bg-zinc-600 w-32 p-4 flex flex-col">
          {/* Brand or logo */}
          <div className="text-white text-xl font-bold mb-8 pl-4">Home</div>

          {/* Navigation links */}
          <Link
            to="/profile"
            className="text-white flex flex-col items-center mb-4 hover:underline"
          >
            <UserIcon className="w-6 h-6" />
            <span className="mt-1">My Profile</span>
          </Link>
          <Link
            to="/tickets"
            className="text-white flex flex-col items-center hover:underline"
          >
            <TicketIcon className="w-6 h-6" />
            <span className="mt-1">Tickets</span>
          </Link>
        </nav>

        {/* Main content */}
        <div className="flex-grow p-8">
          <h1 className="text-3xl font-bold text-blue-800">
            Welcome, {username}!
          </h1>
          <div className="flex justify-center">
            <img
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaUAAAB3CAMAAACUja8MAAAAwFBMVEX///8DS3sIgjYARngAOnEAOXFaeZkASXoAQXUAdxjM1N4AeRzh7eUAeiAAfSmZqr3R4dXv9vIAfy/b4eiKn7UQT37h5uuWvqEcVIGot8YANG681cLp7fFboG/u9fAAfiyfxKkoW4WpybH09vhohaKJuJba6N4AcgCer8G5xdIAbABMmWJ3roYAMGw0j1B+lq7C2ck7ZoxnpXgAJmdMb5JyjahbfJsoi0eDtJBSm2dyq4LCzNckikYAIGUAKmk2YoogY08sAAAR8klEQVR4nO2de1viuhbGgbbSgkUpilJQVFRgdEQdx9HRvf3+3+ok6W0la4WmQMGzn75/7DOHtLn9mstauVirVapUaVPq3u5LulXCJ72+Xr2JeCYnikpr63DaljS9kMNbvxy9fvX4I+c/lCj2d1CO/7YO/YYs71wKb9l1vRxBqevJMbQrSpsWohTcSeEVpe8gRKnRHsLwitJ3EKbU6MDwitJ3EEFp/BeEV5S+gwhKDe8wC68ofQdRlBqNLLyi9B1EUurcpOEVpe8gui15aUVXlL6DaErBQxJeUfoOoik1/Ks4vKL0HaSh1PC7UXhF6TtIR2l8FoVXlL6DdJQa3qMIL5vS7GUv0av4YaD+oKo/P1hcX+8tE39s9CL9NCPjmmcPvWgSm+kSu6aeH31on997mbMHPl7oQI3EO0soNQIRjijBlYt/WvyRtSgtbCvRsfjhKPuhTlTrte24rmstlSvqN5R+CydU6oMssRCHfly7+sTcU/R8a9EMbX3m7AFP0Vmed+qdZZQ69xQlezTJNKqtTenITWJunqo/HKsPH9i21VzStmNZgpIj/0Z++oM0sbqDErNsa0kizUvl+fmp4y7NnDuQUzSRm0ep4d0SlIhPbluU5rZhCSlK9bBXiNLczUlModS7tPO+n3IoBX946qFS2J1RelWqXS+SkvVUhNK1UmwsmdLsZ34bL4dSw79gD7zIzX5nlC7Ni0dSqjsf5pSe8hOTKP02+YJKoiRW10eO9JXsitLlsjFCEU2piYd7HaUvg6qElH4vmwinKouSWF2fSVnYEaWXIoWjKdXj+VI+pVeTxAClmVlfXBalaHX9C37Gu6E0Qx8rmwprZdOU6q4ZpQFqhVRadto01aFb84IbcpttEKo/w9pF74UzA0pidb0Pc7ETSiOlHizbefl9dKCVjtKRCaWJ3MXX3fD4dUEkktrJp/LzTTu8pDPHrcse+nWRYbJwOi0TSuNnqeJ2RGlPGpSa4V4rP2KCUh2ZthSlaykx152Nlic0kNp50/6akwa0Vr3sfbuveSaHUrS6Dr6WXVCSuxTrlLJ8kChK1m/lIYKS3G5t0hiWJH9B9tyw4KkgJV3J8iiJ1XVQTbugJH3dpN1DiKJUD5WPlaD0Gw7v7iI3HakpNd2chkdoI5TE6voizfoOKE3g143dRhqRlCzFp0pQgq9Ze/npfMFRiXRw5GgzbUmsrjeTvOyAkjR5Na4HSCnrsR15RMOU5rBp2PkjjNRBugemxQbaDCWxuv6RZGYHlODcwaJXMwgBSnYrdYMq3jdMCfauJpU+A59Qs2maOajNUIpW15Pc74AS7IMc4y4FUupldSmbtpgSbErITU4IOtBcehErRytR+sSY2t0s+9unBEqBlwv0ktpS1mM3LfgQotQDnwS92KEIfkL0GlaeVqHkHyp13ohX1+MOe/uU4LBUoOOXKWXDjRQFogSHJZNJtUSVXu7NjWIFSl7tvoMwidX1qG1vnxKwzfXFwJIp1S7TxgS/eERJMuANmsZ8tU8IajVKtQD3eXx1PfKcbJ8S7PmJ1HVSKLXSuZgLTFtECcxUjOb8B4CSbeARIbQipUfc53XearH9tn1KwB6hFh90UigB2MC0RZSAl8VoWPoNPiFnpWFpVUq1M9yaxOo6d45vnxIwSKR5+KinFQ9WKWU+YzB+IEpgWdxa9PUpxIlIDd0uUGygVSl127jL+xMXdOuUoOdBctgsftq0HJFHlRJw/YRp14QoQRvV0sQf6R/RcoDnoUhDh1qVUu0KG1H+SY3v4dk+pRGYRUnj8wIMCbLUVcCIUrYikc3nVUoj470V8dwC9pCrTfFWp1S7I/q8c5GprVPqb4oSGOnTOfbalMDE3cTpR2l1Svt4AiFW13vh1ilBo9aFjoPClGpZzIkrR6VEumhNKZnMNgitTql2gvs8sbq++BdHsUVK0M4sTmmATFuVUu//i1LtE/d5Pv99t20JOsqKU8pM28TbvdEebweUbglHET+7TiwXb3H2sCalj/S3eLa4NiXort/67IGJchQdklFskRLcXgLOAXAB41dLCZq2YlFVpTSBlJpL99n/FJQuwUz8q0CxgdaiRDmKGmQU27OXpH0LM/mMCbBc9JSyrQHRjAzZS4BS82v5mRVB6Qku9hcoNtB6lChH0Q0VRcm+B0OvM/Co6SmBRT5h2iJKoEXifWGEXqGHqECxgdajVDsb4z6PAlAypUu1L6NlRilrmRbvoBClJ9AiTbbBwMHR0e3TWq41KXXxbDw7uw5UMiX4uYb6LTpmlED03LRFlH4XdMBLi1+FN3kJrUmJdBRd4SjWopRVi47SkVlFGFICpm2doARXIkxW7+HxLit/WxildSlRjqJ2F0WxFqWXXEpw+RRte8xkSgmYtjNM6QNaZwYDk7wLrUC5M61N6Vyzui5rLUpZXcZTA0QJ7qVq6lcHTCkBB6mNKcFaN1oGPAajprPSMuDalChHUXx2HWgdSuDbjW13vIcIVgRxuiWWMSVg2h7NVUrSXMWk1uFAtpr3YX1KtT+4zwvUKNahBOyN2LeGKcF5VFNrlBhTAmm6YE9FTAmOgiazPNhFog3ORtoAJcJRJFbXodagRGzZwZRa0CGgHSzMKYFd79jakU4OmOwigoeeTfewy9lZn1LtjXAUKReGr06pD48KxbNsYjf/sbQVmzgey2VOSZrbq5SkLq9p0Dhgl2ey+x9pE5QIR5FYXQdS5xjGlFrwfoRkAZWgBHf5Mkz0B16AknpoTaIkn6HI31rWl0/S6CehOm2EEuEoEmfXM63YliYLqXyJv5s6ZSZ7v51XyrYtQIl0p6f+Hfnej3CRtzNIPsTvXhad6G2EUu2ZcBRJN8OvQqk/vw6Vuo9rg6IkH7erW+HLrKdWXhFKNeIGjZTSXE7MDa8HKDGpKHLLbDqnB60ip5g2Q4lyFEk3wxtQUvf7OI56e0zao5Onn7+Upy2XRyEJzohF5S2jhE9TA1/pE04sJHYqpblTW2YTZ07oX3qz/2YoUY4i6WZ4E0raFbs0g8nnSlIahQbXD2XVmksp292fKqNkthQIDhacmt1F4dK23oYoUY4ieDP8JihlUwL6vod57o0zQAaU5qgxgXWH1k+DRAClUe4VREIlUuI9LOUoAjfDb4CSnc1gNXenzApgMqAkH7TkgqtDcwNM8JBOz6ipl0ipz+vvgnAUZavr61OCJ8F19xDNDe5jimVCqaVSdwomJh2l6rsGnV6Zbekf3poIR1G2ur4upeZPuBlSe6dXr778+rlMJpSUOyTUldb+cV5i8oG3yYuTm7kyKYXc60E5itLV9fUoNe1LKW9LbjE8yrkmMJERJdW0VdfDD3ISU48lzq280alMSo5wZlGOogTGGpQsN/xSXAnL7pqcHNQdg77FiJJ8sQO1a+HgeFli+PDo/Ct0l12FWSqlaJKMe7x0dd2EEmFw2HZovc6QowyYVvh2J36Pz6sVkuYIMGX4g/1fmaFCUprINtwvKrHZa1OXmEOsPo0G16f6zP3U2EtZRn+tQcnlYztx3DZZXTeg1G9h9fqkRQ8f1eS5NuoR8SnvTcD/p10HPfxSocQKZ472SORn1IhStCmKcBTFq+vVfeKly4RSNEDgkSleXa8olS4TStHS2xCfEIxW1ytKpcuIUrRCRziKxOp6Ral0mVESS8WEo0isrleUSpcZpWjvDuUouq0obUGGlCKj6QH1eXx1vaJUukwpCaOJOG7rX1SUypcppchouiEcRd2KUukyphQZTQgSX12vKJUtY0qR0UQ5ii6UBlZR2rjMKUVG01/sKFJVUdq4ClCK9tfikcmA0vAE6kY9XdMdXsRBOIOPSdBQ+nn/5uQmTufm5EQ+ln3L09AFRvl5e747+3txi0PY8+i4QqLDk+f39+cbTfh5Vkj5YGuXxYlT0pc5LXFW6AKUIqOJcBTlU3prd4Cm53LovefHIb764pWfBLXl7emP0840rv5px5PPvg09FtN7VBcs8EKN9KTtj4MgGHe8B5RV9ry6Dz7W4We7w1/r+J0hDu2epYXodORKPGdxojfup8njypHywyCLp+M/xz9OPUk/lNikbU/CaHqnDq/nUfJ8Vt0sLGD/6yuUHljA2BdqK+/dsGGQVQuXdy8Xxm/4MSWv0VEo8S8v2pjB5p+dCyXSMxbcYUX1g0aA8uppjnizzyJojNue12a5xSC7wTgtBCugFHbuNXyVkihzVDD5DIuYMKcRec9JHIqU6CRK4oAOcS9bLqXDIVenEfx95P+QwvgZqfb9MJL82u2U1efDVRQkd1y5lKJFSoLSBct/MGSd7i3DFaiXI+go8dprv7GSnXMPDLr5gp8U95JCKMUgKN3wON6oh/miuJ9FRN+wgSRvIRRGE+EoyqOU1gAx8HBImq7+jH3tz3RQHqUgqhmCEqvPTvwtsqmQelBYR4lZiklEbJ4rb+6NzH31KEoqgpJHndYTumMt9p4MWaaetL0wMpqwo2gNSo/sg37XvsCMZjooh9KYf5M1itJhO8sF6xYC5QSqjhIvWPLv50DNFjNG9HWLKfEy45OvQn8auIvOV0/Z286NJsJRtDqlE/aREqMx120bfbSpcii1z6PSYkpXnfTF6HtDeSQpeQCDFIUQ4+Zrp4aY0pIy8+5DV2a9FErRoUTCUbQypfsxK/8JOdt+5G1CExejFMSvjSlKXfYfn6LE8t5OB1/eKlAeKUr7oAXyfCnVzmjzcyjMPCBm4pgSLPONHHQleuszob9psSbqFgplg4RKKTp+vMG2xM3ksTLxjMUqmhrIhLgFEcRTWbItsZrrvNGUsu6KVZcZpVsfJHLoqyk+RH0gMw+omTiixD6OtMztv1KQmP01AqGxH8TfU+uXvB3pX2XT2FzZSRfdi0E4itah1GlH8jAlelocUYpe8zWUWB69801SSuNZQonlJ5DPOugoJWWeKpSYbelF5WIVE3xGv6ltRb199FrZNxjvQPy7pM8rRumNd1j7sWQ7gNXGWC0DCOsMo5dQnUWUWBfPJoiIEhsTsgyemfZ45/B33OOxmRmPtMuLwBDkUeJlHtJl5ooDnjvp7Hei7mqXr/pBR1CdOHhjlNhQrOvW+CzlUxNX7uxBvN5+9FVKfLxKB3p8s5KnGQo9MCvjoOVp9xsYG1nnkEdpSZmh/mS9hLo32JIu41PPxaWXlwz1fV4xSmLCqHmBdQxtjV1nQIn3Zw9oYnsO6pvNylUmgSY3d2D2/RnfjiqlmOI2oHS7pMxA70FaMvXsQd19yiYQ6I/5ZjfUERf4r0SJ9+nEtTlC7KNtBLSxaEIpWvhSzQ9W3/Hx7W4D26KsWGPKkB5mVsF9B9950WbpxDP1+3xK/AyLrsyZDsGIO0Mb7a1k2/kAb2bPbk7VO4oKUjqcMhTth2jyqYR1eGv6FCHvF2oR8ilxyojSPkvPfzgZXt2zWvDVcY/Pi8b+HU9QmSCM2czr5urq5LPDJpdqIa7S187+5M8eojJHj5/J30Q3+pHpjlfwNG6/feKQnevsHR292sRfBwfXVBDHbVeiVLuajpO5p1r6fT+dl/ry52tESfRfyJR/9MZiEs/+6+EP+s0LohR9Ja8PfjR9ZjEGlD85fk0kKQVR3tarafL4WO76utMgEXtgmhZMHXri9kQe8pBukNU5irSUfnhTcmLNZjOJSx6F3TTikKnsgXmcetPHNNoLKWw49X7sJ//ypujL6N77beFxfqAcAMOHOEE1r1efnngrIAvx+N5OFxYUnzjLIEro9tmPH5aRdn+ABYqHzJ+BDwLrJV3Mo3MUaSl1uxqnnAgSMg/KfskJI9PcP2TKyQ3+/Zy/pV+J7nbpvGryoH2YDDg1PrCqnPvSOIqqFfUyhA4Ca+Uo5/aIv/RYUSpL5B1XhNBF0bSjqKJUiiaGh7/xn0ImLvCvKJUlo8tCwJ8Ay0RN8ypKJWlgMDSF1BFr4l62ilJpOsjFFNJ/jZW4wL+iVJoGyzu9Zqj5G+HEvWwVpfL0od5YB2VpruGsUY6iilKJGj3pnBBN+3LJ5YnIUVRRKlUDm7yIxnU0vV0k5CiqKJWsA1ft9yzbPsq5X1a9wL+iVLrme47tutEfVXNd29kzuPj802tD/agobUGt2eKV/02118XA4G/b1KJNGVAl569SpUqVKv1H9T9fetdFUcoFGAAAAABJRU5ErkJggg=="
              alt=""
            />
          </div>
          <p className="mt-4 flex justify-center text-2xl text-gray-700">
            You are now on the home page.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;
