import React, { useState, useEffect } from "react";
import axios from "axios";
import { Dialog } from "@headlessui/react";

const MyProfile = ({ userId }) => {
  // State variables to hold user information and dialog visibility
  const [userDetails, setUserDetails] = useState({
    photo: "",
    name: "",
    email: "",
    contactNumber: "",
    dateOfBirth: "",
    city: "",
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Function to fetch user details
  const fetchUserDetails = async () => {
    try {
      const response = await axios.get(`/api/users/${userId}`);
      setUserDetails(response.data);
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  };

  // Fetch user details when the component mounts
  useEffect(() => {
    fetchUserDetails();
  }, [userId]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Update user details
      const response = await axios.put(`/api/users/${userId}`, userDetails);
      if (response.status === 200) {
        // Successfully updated user details
        setIsDialogOpen(false);
        fetchUserDetails(); // Reload profile details
      } else {
        alert("Failed to update profile. Please try again.");
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("An error occurred while updating the profile.");
    }
  };

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6 text-center text-blue-600">
        My Profile
      </h1>

      <div className="flex justify-between">
        {/* User photo */}
        <div className=" justify-start mb-8">
          <img
            //   src={userDetails.photo}
            src={
              "https://media.istockphoto.com/id/469986766/photo/close-up-portrait-of-child-looking-up.jpg?s=170667a&w=0&k=20&c=7s9KHlN5E-ZfndTEJN70th0f5pnaOl47vta85mK7A5I="
            }
            alt="User Profile"
            className="w-32 h-32 rounded-full object-cover"
          />
        </div>
        {/* Edit button */}
        <div className=" justify-end mb-4">
          <button
            className="bg-blue-500 text-white p-3 rounded-full font-bold shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            onClick={() => setIsDialogOpen(true)}
          >
            ✎ Edit Profile
          </button>
          {/* <span className="text-blue-500 text-sm ml-2 self-center">
          Edit Details
        </span> */}
        </div>
      </div>

      {/* Display user information in a table */}
      <table className="w-full border-collapse mb-6">
        <tbody>
          <tr>
            <td className="border font-semibold p-2">Name:</td>
            <td className="border p-2">{userDetails.name}</td>
          </tr>
          <tr>
            <td className="border font-semibold  p-2">Email:</td>
            <td className="border p-2">{userDetails.email}</td>
          </tr>
          <tr>
            <td className="border font-semibold  p-2">Contact Number:</td>
            <td className="border p-2">{userDetails.contactNumber}</td>
          </tr>
          <tr>
            <td className="border font-semibold  p-2">Date of Birth:</td>
            <td className="border p-2">{userDetails.dateOfBirth}</td>
          </tr>
          <tr>
            <td className="border font-semibold  p-2">City:</td>
            <td class="border p-2">{userDetails.city}</td>
          </tr>
        </tbody>
      </table>

      {/* Edit Profile dialog box */}
      <Dialog
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
      >
        <Dialog.Panel className="bg-white p-8 rounded shadow-lg w-full max-w-md">
          <Dialog.Title className="text-lg font-bold mb-4">
            Edit Profile
          </Dialog.Title>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Form fields */}
            <div>
              <label
                htmlFor="name"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Name:
              </label>
              <input
                type="text"
                id="name"
                value={userDetails.name}
                onChange={(e) =>
                  setUserDetails({ ...userDetails, name: e.target.value })
                }
                className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Email:
              </label>
              <input
                type="email"
                id="email"
                value={userDetails.email}
                onChange={(e) =>
                  setUserDetails({ ...userDetails, email: e.target.value })
                }
                className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label
                htmlFor="contactNumber"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Contact Number:
              </label>
              <input
                type="text"
                id="contactNumber"
                value={userDetails.contactNumber}
                onChange={(e) =>
                  setUserDetails({
                    ...userDetails,
                    contactNumber: e.target.value,
                  })
                }
                className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label
                htmlFor="dateOfBirth"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Date of Birth:
              </label>
              <input
                type="date"
                id="dateOfBirth"
                value={userDetails.dateOfBirth}
                onChange={(e) =>
                  setUserDetails({
                    ...userDetails,
                    dateOfBirth: e.target.value,
                  })
                }
                className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label
                htmlFor="city"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                City:
              </label>
              <input
                type="text"
                id="city"
                value={userDetails.city}
                onChange={(e) =>
                  setUserDetails({ ...userDetails, city: e.target.value })
                }
                className="mt-1 w-full px-3 py-2 border rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Update Profile button */}
            <button
              type="submit"
              className="w-full bg-blue-500 text-white py-2 rounded shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Update Profile
            </button>

            {/* Cancel button */}
            <button
              type="button"
              className="mt-4 w-full bg-red-500 text-white py-2 rounded shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
              onClick={() => setIsDialogOpen(false)}
            >
              Cancel
            </button>
          </form>
        </Dialog.Panel>
      </Dialog>
    </div>
  );
};

export default MyProfile;
